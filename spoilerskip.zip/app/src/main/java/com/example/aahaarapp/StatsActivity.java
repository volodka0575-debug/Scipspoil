package com.example.aahaarapp;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class StatsActivity extends AppCompatActivity {

    private TextView total, today, last;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stats);

        total = findViewById(R.id.statTotal);
        today = findViewById(R.id.statToday);
        last = findViewById(R.id.statLast);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnResetStats).setOnClickListener(v -> {
            Prefs.resetStats(this);
            refresh();
        });
        refresh();
    }

    private void refresh() {
        total.setText(String.valueOf(Prefs.getTotal(this)));
        today.setText(String.valueOf(Prefs.getToday(this)));
        String w = Prefs.getLastWord(this);
        last.setText(w.isEmpty() ? "—" : w);
    }
}
