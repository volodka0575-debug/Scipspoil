package com.example.aahaarapp;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Хранилище настроек и статистики. */
public final class Prefs {

    public static final String DEFAULT_KEYWORDS =
            "мстител\n"
            + "судный день\n"
            + "avengers\n"
            + "doomsday\n"
            + "доктор дум\n"
            + "doctor doom";

    private static final String FILE = "spoilerskip";
    private static final String K_ENABLED = "enabled";
    private static final String K_KEYWORDS = "keywords";
    private static final String K_WHITELIST = "whitelist";
    private static final String K_TOTAL = "total";
    private static final String K_DAY = "day";
    private static final String K_DAY_COUNT = "day_count";
    private static final String K_LAST_WORD = "last_word";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    private static String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    public static boolean isEnabled(Context c) { return sp(c).getBoolean(K_ENABLED, true); }

    public static void setEnabled(Context c, boolean v) { sp(c).edit().putBoolean(K_ENABLED, v).apply(); }

    public static String getKeywords(Context c) { return sp(c).getString(K_KEYWORDS, DEFAULT_KEYWORDS); }

    public static void setKeywords(Context c, String v) { sp(c).edit().putString(K_KEYWORDS, v).apply(); }

    public static String getWhitelist(Context c) { return sp(c).getString(K_WHITELIST, ""); }

    public static void setWhitelist(Context c, String v) { sp(c).edit().putString(K_WHITELIST, v).apply(); }

    public static void recordSkip(Context c, String word) {
        SharedPreferences s = sp(c);
        String day = today();
        int dayCount = day.equals(s.getString(K_DAY, "")) ? s.getInt(K_DAY_COUNT, 0) : 0;
        s.edit()
                .putInt(K_TOTAL, s.getInt(K_TOTAL, 0) + 1)
                .putString(K_DAY, day)
                .putInt(K_DAY_COUNT, dayCount + 1)
                .putString(K_LAST_WORD, word)
                .apply();
    }

    public static int getTotal(Context c) { return sp(c).getInt(K_TOTAL, 0); }

    public static int getToday(Context c) {
        SharedPreferences s = sp(c);
        return today().equals(s.getString(K_DAY, "")) ? s.getInt(K_DAY_COUNT, 0) : 0;
    }

    public static String getLastWord(Context c) { return sp(c).getString(K_LAST_WORD, ""); }

    public static void resetStats(Context c) {
        sp(c).edit().remove(K_TOTAL).remove(K_DAY).remove(K_DAY_COUNT).remove(K_LAST_WORD).apply();
    }
}
