package com.example.aahaarapp;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Автотест без TikTok: показывает «ленту» из фейковых видео. Спойлерные должна
 * пролистать сама служба SpoilerSkip, обычные — остаться (их мы листаем по таймеру).
 * Экран не трогайте — просто смотрите.
 */
public class FeedTestActivity extends AppCompatActivity {

    private static final String[] USERS = {
            "@chef_masha", "@marvel_leaks", "@cats_daily", "@cinema_news",
            "@run_with_me", "@theory_hub", "@pc_build", "@fan_edit"};
    private static final String[] DESCS = {
            "Паста карбонара за 10 минут 🍝 #еда #рецепты",
            "ПОЛНЫЙ РАЗБОР: кто погибнет в Мстители: Судный день 😱 #спойлер",
            "Кот впервые видит снег ❄️ #коты #милота",
            "Утечка концовки Avengers: Doomsday — смотреть до конца #marvel",
            "Утренняя пробежка 5 км, лайфхаки для начинающих #спорт",
            "Доктор Дум и пост-титры: что скрывали в трейлере #мстители",
            "Как собрать игровой ПК в 2026 за разумные деньги #пк",
            "Doctor Doom — все слитые сцены Doomsday #leak"};
    private static final boolean[] SPOILER = {
            false, true, false, true, false, true, false, true};
    private static final int[] COLORS = {
            0xFF1B0B3D, 0xFF2A0F57, 0xFF150833, 0xFF33106B};

    private static final long SAFE_MS = 3500;
    private static final long SPOILER_MS = 7000;
    private static final int OK = 1, BAD = 2;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable timeout = new Runnable() {
        @Override
        public void run() {
            onTimeout();
        }
    };

    private View startPanel, cardPanel, resultPanel;
    private TextView cardUser, cardDesc, cardCounter, resultVerdict, resultText;

    private boolean running = false;
    private int index = -1;
    private int[] result = new int[USERS.length];
    private float downY;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_feedtest);

        startPanel = findViewById(R.id.startPanel);
        cardPanel = findViewById(R.id.cardPanel);
        resultPanel = findViewById(R.id.resultPanel);
        cardUser = findViewById(R.id.cardUser);
        cardDesc = findViewById(R.id.cardDesc);
        cardCounter = findViewById(R.id.cardCounter);
        resultVerdict = findViewById(R.id.resultVerdict);
        resultText = findViewById(R.id.resultText);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnStart).setOnClickListener(v -> start());
        findViewById(R.id.btnRetry).setOnClickListener(v -> start());
        findViewById(R.id.btnClose).setOnClickListener(v -> finish());

        cardPanel.setClickable(true);
        cardPanel.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downY = e.getY();
            } else if (e.getAction() == MotionEvent.ACTION_UP) {
                if (e.getY() - downY < -dp(120)) onSwipeUp();
            }
            return true;
        });
    }

    private float dp(int v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private void start() {
        if (!MainActivity.isServiceEnabled(this)) {
            Toast.makeText(this, "Сначала включите SpoilerSkip в спец. возможностях (экран «Помощь»)",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (!Prefs.isEnabled(this)) {
            Toast.makeText(this, "Включите переключатель защиты на главном экране",
                    Toast.LENGTH_LONG).show();
            return;
        }
        result = new int[USERS.length];
        index = -1;
        running = true;
        SkipService.selfTestActive = true;
        startPanel.setVisibility(View.GONE);
        resultPanel.setVisibility(View.GONE);
        cardPanel.setVisibility(View.VISIBLE);
        next();
    }

    private void next() {
        handler.removeCallbacks(timeout);
        index++;
        if (index >= USERS.length) {
            finishTest();
            return;
        }
        cardPanel.setBackgroundColor(COLORS[index % COLORS.length]);
        cardUser.setText(USERS[index]);
        cardDesc.setText(DESCS[index]);
        cardCounter.setText((index + 1) + "/" + USERS.length);
        cardPanel.setAlpha(0f);
        cardPanel.setTranslationY(dp(60));
        cardPanel.animate().alpha(1f).translationY(0f).setDuration(220).start();
        handler.postDelayed(timeout, SPOILER[index] ? SPOILER_MS : SAFE_MS);
    }

    /** Время вышло: спойлер не пролистан (плохо) / обычное видео осталось (хорошо). */
    private void onTimeout() {
        if (!running) return;
        result[index] = SPOILER[index] ? BAD : OK;
        next();
    }

    /** Кто-то (служба) сделал свайп вверх: спойлер пролистан (хорошо) / обычное пропущено зря (плохо). */
    private void onSwipeUp() {
        if (!running) return;
        handler.removeCallbacks(timeout);
        result[index] = SPOILER[index] ? OK : BAD;
        next();
    }

    private void finishTest() {
        running = false;
        SkipService.selfTestActive = false;
        cardPanel.setVisibility(View.GONE);
        resultPanel.setVisibility(View.VISIBLE);

        boolean allOk = true;
        boolean missedSpoiler = false;
        boolean falseSkip = false;
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < USERS.length; i++) {
            boolean ok = result[i] == OK;
            if (!ok) {
                allOk = false;
                if (SPOILER[i]) missedSpoiler = true; else falseSkip = true;
            }
            sb.append(ok ? "✔ " : "✘ ").append("Видео ").append(i + 1).append(": ");
            if (SPOILER[i]) sb.append(ok ? "спойлер — пролистано" : "спойлер — НЕ пролистано");
            else sb.append(ok ? "обычное — осталось" : "обычное — ЛИШНИЙ пропуск");
            sb.append("\n");
        }

        if (allOk) {
            resultVerdict.setText("Антиспойлер работает ✔");
            resultVerdict.setTextColor(Color.parseColor("#9DFFB0"));
        } else {
            resultVerdict.setText("Есть проблемы ✘");
            resultVerdict.setTextColor(Color.parseColor("#FF9D9D"));
            if (missedSpoiler) {
                sb.append("\nСпойлеры не пролистались. Проверьте: включена ли служба, нет ли в «Слова-спойлеры» ")
                  .append("слов «мстител», «avengers», «doomsday», «доктор дум», «doctor doom»; ")
                  .append("в «Проверке работы» попробуйте тестовый свайп.");
            }
            if (falseSkip) {
                sb.append("\nОбычные видео пропускались зря — в списке слов есть слишком общее слово, ")
                  .append("либо его стоит добавить в белый список.");
            }
        }
        sb.append("\n\nЭтот тест проверяет цепочку «чтение текста → решение → свайп». ")
          .append("Как именно TikTok отдаёт текст, проверяется в «Проверке работы» → «Что служба видит».");
        resultText.setText(sb.toString());
    }

    private void abort() {
        running = false;
        SkipService.selfTestActive = false;
        handler.removeCallbacks(timeout);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (running) {
            abort();
            cardPanel.setVisibility(View.GONE);
            resultPanel.setVisibility(View.GONE);
            startPanel.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        abort();
        super.onDestroy();
    }
}
