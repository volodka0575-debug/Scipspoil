package com.example.aahaarapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Проверка работы: статус службы, проверка текста по словам, тестовый свайп. */
public class TestActivity extends AppCompatActivity {

    private TextView status, result, seen;
    private EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        status = findViewById(R.id.testStatus);
        result = findViewById(R.id.testResult);
        seen = findViewById(R.id.testSeen);
        input = findViewById(R.id.testInput);

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnAutoTest).setOnClickListener(v ->
                startActivity(new android.content.Intent(this, FeedTestActivity.class)));
        findViewById(R.id.btnRefresh).setOnClickListener(v -> refresh());

        findViewById(R.id.btnCheck).setOnClickListener(v -> {
            String text = input.getText().toString();
            String hit = WordMatcher.findHit(text, Prefs.getKeywords(this), Prefs.getWhitelist(this));
            if (hit != null) {
                result.setText("Будет пропущено ✔ (сработало: «" + hit + "»)");
            } else if (isWhitelisted(text)) {
                result.setText("Не пропустится: сработал белый список");
            } else {
                result.setText("Не пропустится: слов-спойлеров не найдено");
            }
        });

        findViewById(R.id.btnSwipe).setOnClickListener(v -> {
            if (SkipService.requestTestSwipe(5000)) {
                Toast.makeText(this,
                        "Через 5 секунд будет свайп вверх. Откройте TikTok!",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this,
                        "Служба не запущена: включите SpoilerSkip в спец. возможностях",
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private boolean isWhitelisted(String text) {
        String t = WordMatcher.normalize(text);
        for (String w : WordMatcher.parse(Prefs.getWhitelist(this))) {
            if (t.contains(w)) return true;
        }
        return false;
    }

    private static String mark(boolean ok) { return ok ? "✔ " : "✘ "; }

    private void refresh() {
        boolean service = MainActivity.isServiceEnabled(this);
        boolean enabled = Prefs.isEnabled(this);
        long at = SkipService.lastTikTokSeenAt;

        String tt;
        if (at == 0) {
            tt = "✘ TikTok пока не замечен (откройте его на пару секунд и нажмите «Обновить»)";
        } else {
            String time = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date(at));
            long ago = (System.currentTimeMillis() - at) / 1000;
            tt = "✔ TikTok замечен в " + time + " (" + ago + " с назад)";
        }

        status.setText(
                mark(service) + "Служба спец. возможностей включена\n"
                + mark(enabled) + "Переключатель защиты включён\n"
                + tt + "\n"
                + "Считано символов текста с экрана: " + SkipService.lastScreenTextLen);

        String sample = SkipService.lastScreenText;
        seen.setText(sample == null || sample.isEmpty()
                ? "— пусто —"
                : sample);
    }
}
