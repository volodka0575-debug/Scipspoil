package com.example.aahaarapp;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class MainActivity extends AppCompatActivity {

    private View hero;
    private View powerCircle;
    private SwitchCompat switchMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        hero = findViewById(R.id.hero);
        powerCircle = findViewById(R.id.powerCircle);
        switchMain = findViewById(R.id.switchMain);

        switchMain.setChecked(Prefs.isEnabled(this));
        switchMain.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Prefs.setEnabled(this, isChecked);
            if (isChecked && !isServiceEnabled(this)) {
                Toast.makeText(this,
                        "Включите SpoilerSkip в «Специальных возможностях»",
                        Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
            refreshState();
        });

        findViewById(R.id.btnSettings).setOnClickListener(v -> openWords(WordsActivity.MODE_KEYWORDS));
        findViewById(R.id.btnWhitelist).setOnClickListener(v -> openWords(WordsActivity.MODE_WHITELIST));
        findViewById(R.id.btnStats).setOnClickListener(v -> startActivity(new Intent(this, StatsActivity.class)));
        findViewById(R.id.btnHelp).setOnClickListener(v -> startActivity(new Intent(this, HelpActivity.class)));
        findViewById(R.id.btnInfo).setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("SpoilerSkip")
                .setMessage("Автоматически пролистывает видео в TikTok, если в описании, "
                        + "хэштегах или подписях есть ваши слова-спойлеры.")
                .setPositiveButton("OK", null)
                .show());

        findViewById(R.id.btnMenu).setOnClickListener(v -> {
            PopupMenu menu = new PopupMenu(this, v);
            menu.getMenu().add(0, 1, 0, "Слова-спойлеры");
            menu.getMenu().add(0, 2, 1, "Белый список");
            menu.getMenu().add(0, 3, 2, "Статистика");
            menu.getMenu().add(0, 4, 3, "Помощь");
            menu.getMenu().add(0, 5, 4, "Проверка работы");
            menu.getMenu().add(0, 6, 5, "Тест антиспойлера");
            menu.setOnMenuItemClickListener(item -> {
                switch (item.getItemId()) {
                    case 1: openWords(WordsActivity.MODE_KEYWORDS); break;
                    case 2: openWords(WordsActivity.MODE_WHITELIST); break;
                    case 3: startActivity(new Intent(this, StatsActivity.class)); break;
                    case 4: startActivity(new Intent(this, HelpActivity.class)); break;
                    case 5: startActivity(new Intent(this, TestActivity.class)); break;
                    case 6: startActivity(new Intent(this, FeedTestActivity.class)); break;
                }
                return true;
            });
            menu.show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private void openWords(String mode) {
        Intent i = new Intent(this, WordsActivity.class);
        i.putExtra(WordsActivity.EXTRA_MODE, mode);
        startActivity(i);
    }

    /** «Включено» = переключатель on И служба спец. возможностей реально включена. */
    private void refreshState() {
        boolean active = Prefs.isEnabled(this) && isServiceEnabled(this);
        powerCircle.setActivated(active);
        hero.animate().alpha(active ? 1f : 0.35f).setDuration(250).start();
    }

    public static boolean isServiceEnabled(Context c) {
        String enabled = Settings.Secure.getString(
                c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        ComponentName me = new ComponentName(c, SkipService.class);
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            ComponentName cn = ComponentName.unflattenFromString(splitter.next());
            if (me.equals(cn)) return true;
        }
        return false;
    }
}
