package com.example.aahaarapp;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Редактор списка слов: слова-спойлеры или белый список. */
public class WordsActivity extends AppCompatActivity {

    public static final String EXTRA_MODE = "mode";
    public static final String MODE_KEYWORDS = "keywords";
    public static final String MODE_WHITELIST = "whitelist";

    private boolean keywordsMode;
    private EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_words);

        keywordsMode = !MODE_WHITELIST.equals(getIntent().getStringExtra(EXTRA_MODE));

        TextView title = findViewById(R.id.title);
        TextView hint = findViewById(R.id.hint);
        input = findViewById(R.id.input);
        TextView reset = findViewById(R.id.btnReset);

        if (keywordsMode) {
            title.setText("Слова-спойлеры");
            hint.setText("Если на экране TikTok есть любое из этих слов — видео пролистывается. "
                    + "Одно слово или фраза в строке. Регистр не важен, «мстител» поймает "
                    + "«Мстители», «мстителей» и #мстители.");
            input.setText(Prefs.getKeywords(this));
            reset.setOnClickListener(v -> input.setText(Prefs.DEFAULT_KEYWORDS));
        } else {
            title.setText("Белый список");
            hint.setText("Если в видео есть любое из этих слов — оно НЕ будет пропущено, "
                    + "даже если нашлось слово-спойлер. Например, имя блогера, которого вы "
                    + "точно хотите смотреть. Одно слово или фраза в строке.");
            input.setText(Prefs.getWhitelist(this));
            reset.setText("Очистить");
            reset.setOnClickListener(v -> input.setText(""));
        }

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
        findViewById(R.id.btnSave).setOnClickListener(v -> {
            String text = input.getText().toString();
            if (keywordsMode) Prefs.setKeywords(this, text);
            else Prefs.setWhitelist(this, text);
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}
