package com.example.aahaarapp;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Поиск слов-спойлеров в тексте с экрана. */
public final class WordMatcher {

    private WordMatcher() {}

    public static String normalize(String s) {
        return s.toLowerCase(Locale.ROOT).replace('ё', 'е');
    }

    public static List<String> parse(String raw) {
        List<String> out = new ArrayList<>();
        if (raw == null) return out;
        for (String line : raw.split("\\r?\\n")) {
            String w = normalize(line.trim());
            if (!w.isEmpty()) out.add(w);
        }
        return out;
    }

    /**
     * @return найденное слово-спойлер или null, если пропускать не нужно
     *         (слов нет, либо сработало слово из белого списка).
     */
    public static String findHit(String screenText, String keywords, String whitelist) {
        String text = normalize(screenText);
        for (String w : parse(whitelist)) {
            if (text.contains(w)) return null;
        }
        for (String k : parse(keywords)) {
            if (text.contains(k)) return k;
        }
        return null;
    }
}
