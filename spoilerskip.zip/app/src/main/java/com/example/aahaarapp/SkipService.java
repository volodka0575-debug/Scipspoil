package com.example.aahaarapp;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;

/**
 * Следит за экраном TikTok. Если в видимом тексте (описание, хэштеги, подписи)
 * есть слово-спойлер — делает свайп вверх, то есть листает к следующему видео.
 */
public class SkipService extends AccessibilityService {

    private static final long CHECK_DELAY_MS = 350;
    private static final long SKIP_COOLDOWN_MS = 1100;
    private static final int MAX_NODES = 700;
    private static final int MAX_DEPTH = 40;
    // защита от бесконечного листания: не больше 6 пропусков за 8 секунд
    private static final int LOOP_LIMIT = 6;
    private static final long LOOP_WINDOW_MS = 8000;
    private static final long LOOP_PAUSE_MS = 8000;

    // --- диагностика для экрана «Проверка» ---
    private static SkipService instance;
    /** true только пока открыт экран автотеста: тогда служба читает и собственное приложение. */
    public static volatile boolean selfTestActive = false;
    public static volatile long lastTikTokSeenAt = 0;
    public static volatile String lastScreenText = "";
    public static volatile int lastScreenTextLen = 0;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayDeque<Long> recentSkips = new ArrayDeque<>();
    private boolean checkPending = false;
    private long lastSkip = 0;
    private long pausedUntil = 0;

    private final Runnable checkRunnable = new Runnable() {
        @Override
        public void run() {
            checkPending = false;
            check();
        }
    };

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!Prefs.isEnabled(this)) return;
        if (checkPending) return;
        checkPending = true;
        handler.postDelayed(checkRunnable, CHECK_DELAY_MS);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onInterrupt() {
    }

    /** Тестовый свайп через delayMs. false — служба не запущена. */
    public static boolean requestTestSwipe(long delayMs) {
        final SkipService svc = instance;
        if (svc == null) return false;
        svc.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                svc.performSwipe();
            }
        }, delayMs);
        return true;
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private static boolean isTikTok(String pkg) {
        return "com.zhiliaoapp.musically".equals(pkg)
                || "com.ss.android.ugc.trill".equals(pkg)
                || "com.ss.android.ugc.aweme".equals(pkg);
    }

    private void check() {
        long now = SystemClock.uptimeMillis();
        if (now < pausedUntil || now - lastSkip < SKIP_COOLDOWN_MS) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            CharSequence pkg = root.getPackageName();
            String p = pkg == null ? null : pkg.toString();
            boolean self = p != null && p.equals(getPackageName());
            if (p == null || !(isTikTok(p) || (self && selfTestActive))) return;

            StringBuilder sb = new StringBuilder();
            int[] budget = {MAX_NODES};
            collect(root, sb, budget, 0);

            if (!self) {
                lastTikTokSeenAt = System.currentTimeMillis();
                lastScreenTextLen = sb.length();
                lastScreenText = sb.length() > 600 ? sb.substring(0, 600) : sb.toString();
            }

            String hit = WordMatcher.findHit(
                    sb.toString(), Prefs.getKeywords(this), Prefs.getWhitelist(this));
            if (hit != null) skip(hit, now, self);
        } finally {
            root.recycle();
        }
    }

    /** Собирает текст только с видимых элементов, поля ввода (поиск) пропускает. */
    private void collect(AccessibilityNodeInfo node, StringBuilder sb, int[] budget, int depth) {
        if (node == null || budget[0] <= 0 || depth > MAX_DEPTH) return;
        budget[0]--;
        if (!node.isVisibleToUser()) return;

        CharSequence cls = node.getClassName();
        boolean isEdit = cls != null && cls.toString().contains("EditText");
        if (!isEdit) {
            CharSequence t = node.getText();
            if (t != null && t.length() > 0) sb.append(t).append('\n');
            CharSequence d = node.getContentDescription();
            if (d != null && d.length() > 0) sb.append(d).append('\n');
        }

        int n = node.getChildCount();
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collect(child, sb, budget, depth + 1);
                child.recycle();
            }
        }
    }

    private void skip(String word, long now, boolean self) {
        // защита от цикла
        while (!recentSkips.isEmpty() && now - recentSkips.peekFirst() > LOOP_WINDOW_MS) {
            recentSkips.pollFirst();
        }
        if (recentSkips.size() >= LOOP_LIMIT) {
            pausedUntil = now + LOOP_PAUSE_MS;
            recentSkips.clear();
            return;
        }

        if (performSwipe()) {
            lastSkip = now;
            recentSkips.addLast(now);
            if (!self) Prefs.recordSkip(this, word);
            // перепроверить новое видео сразу после анимации
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!checkPending) {
                        checkPending = true;
                        handler.post(checkRunnable);
                    }
                }
            }, SKIP_COOLDOWN_MS + 100);
        }
    }

    /** Свайп вверх по центру экрана. */
    private boolean performSwipe() {
        DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.5f;
        Path path = new Path();
        path.moveTo(x, dm.heightPixels * 0.72f);
        path.lineTo(x, dm.heightPixels * 0.28f);

        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path, 0, 220));
        return dispatchGesture(builder.build(), null, null);
    }
}
